<?php
class Contract_model extends CI_Model{

    public function add_contact($id_user, $delivo, $paiment){
           $sql = 'insert into contract(id_user,delivo,paiment) values(?, ?, ?)';
           $result = $this->db->query($sql,array($id_user, $delivo,$paiment));
           return $this->db->insert_id();
    }
 
  
}
