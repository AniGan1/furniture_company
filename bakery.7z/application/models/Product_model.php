<?php
class Product_model extends CI_Model{

    public function product_select($vid=null, $sort=null){
        $d = [];
        $sql = 'select * from product 
                    join vid on product.id_vid=vid.id_vid';
        if($vid && $vid > 0) { 
            $sql .= ' where product.id_vid = ?';
            $d[] = $vid;
        }
        if($sort) {
            $sql .= ' order by product.price '.$sort;
        }
        $result = $this->db->query($sql, $d);
        return $result->result_array();
   }

public function update_col_product($id_product, $col) {
    $sql = 'UPDATE product SET col = col - CAST(? AS SIGNED) WHERE id_produc = ?';
    $result = $this->db->query($sql, array($col, $id_product));
    return $result;
}

public function get_all(){
    $sql = 'select * from product join vid on product.id_vid  = vid.id_vid';   
    $result = $this->db->query($sql);
    return $result->result_array();
   
}

public function get_all_select($date){
    if(!$date){
        $sql = 'select * from product  join vid on product.id_vid=vid.id_vid';   
        $result = $this->db->query($sql);

    }else{
        $sql = 'select * from product  join vid on product.id_vid=vid.id_vid
        where DATE_FORMAT(product.created_at, "%Y-%m-%dT%H:%i") = ?';   
        $result = $this->db->query($sql, [$date]);
    }
   
    return $result->result_array();
   
}


public function add_product($name_produc, $col, $width, $unit, $price, $id_vid, $img){
    $sql = 'insert into product(name_produc, col, width, unit, price, id_vid, img) values(?,?,?,?,?,?,?)';
    $result = $this->db->query($sql,array($name_produc, $col, $width, $unit, $price, $id_vid,$img));
    return $this->db->insert_id();
}
}
