<?php
class Order_model extends CI_Model{
    public function get_order_by_user($id_user){
           $sql = 'select product.name_produc, product.price,users.adres,orders.col,orders.oplata,orders.date,orders.status,orders.id_order from orders  
                        join product on product.id_produc = orders.id_produc
                        join users on users.id_user = orders.id_user
                        where orders.id_user = ?
                        ';
           $result = $this->db->query($sql,array($id_user));
           return $result->result_array();
    }

    public function delete_order($id_order){
        $sql = 'delete from orders where id_order = ?';
           $result = $this->db->query($sql,array($id_order));
           return $result;
    }


    public function edit_order($id_order, $date, $col){
        $sql = 'update orders set date = ?, col = ? where id_order = ?';
           $result = $this->db->query($sql,array($date, $col, $id_order));
           return $result;
    }

    public function edit_order_status($id_order, $status){
        $sql = 'update orders set status = ? where id_order = ?';
           $result = $this->db->query($sql,array($status, $id_order));
           return $result;
    }
    public function report_sales($start_date=null,$end_date=null){
            if($start_date != null && $end_date != null){

        $sql = 'select  
                    product.name_produc as product_name,
                    vid.name_vid as vid_name,
                    orders.date,
                    sum(orders.col) as total_col,
                    sum(orders.col * product.price) as total_summa
                from orders
                    join product on product.id_produc = orders.id_produc
                    join vid on vid.id_vid  = product.id_vid
                where orders.date >= ? and orders.date <= ?    
                group by product.name_produc, vid.name_vid
                order by total_summa desc';
               
                $result = $this->db->query($sql,array($start_date, $end_date));
                
            }else{
$sql = 'select  
                    product.name_produc as product_name,
                    orders.date,
                    vid.name_vid as vid_name,
                    sum(orders.col) as total_col,
                    sum(orders.col * product.price) as total_summa
                from orders
                    join product on product.id_produc = orders.id_produc
                    join vid on vid.id_vid  = product.id_vid
                group by product.name_produc, vid.name_vid
                order by total_summa desc';
                $result = $this->db->query($sql,array());
            }
            return $result->result_array();

    }
  public function orders_select($date=null,$name_product=null,$fio_client=null){
        $sql = 'select orders.*,product.*,users.*,contract.*,vid.*,orders.col as count from orders  
                        join product on product.id_produc = orders.id_produc
                        join users on users.id_user = orders.id_user
                        join contract on contract.id_cont = orders.id_contract
                        join vid on vid.id_vid  = product.id_vid
                        ';
           $conditions = [];
            $params = [];

            if ($date != null) {
               
                $conditions[] = 'DATE(orders.date) = "'.$date.'"';
                $params[] = $date;
            }

            if ($name_product != null) {
                $conditions[] = 'product.name_produc = "'.$name_product.'"';
                $params[] = $name_product;
            }

            if ($fio_client != null) {
                $conditions[] = 'users.fio = "'.$fio_client.'"';
                $params[] = $fio_client;
            }
            if (!empty($conditions)) {
                $sql .= ' WHERE ' . implode(' AND ', $conditions);
            }
         


           $result = $this->db->query($sql,array());
           return $result->result_array();
  }

  public function analiz_products($start_date=null,$end_date=null){
    if($start_date != null && $end_date != null){
        $sql = 'select * from orders  
                    join product on product.id_produc = orders.id_produc
                    join vid on vid.id_vid  = product.id_vid
                    where orders.date >= ? and orders.date <= ?
                    ';
            $result = $this->db->query($sql,array($start_date, $end_date));

    }   else{
        $sql = 'select * from orders  
                    join product on product.id_produc = orders.id_produc
                    join vid on vid.id_vid  = product.id_vid
                        ';
                $result = $this->db->query($sql,array());

    } 
           return $result->result_array();
   

  }


  public function history_orders($start_date=null,$end_date=null){
    if($start_date != null && $end_date != null){
        $sql = 'select * from orders  
                    join product on product.id_produc = orders.id_produc
                    join vid on vid.id_vid  = product.id_vid
                    where orders.date >= ? and orders.date <= ?
                    order by  orders.date desc
                    ';
            $result = $this->db->query($sql,array($start_date, $end_date));

    }   else{
        $sql = 'select * from orders  
                    join product on product.id_produc = orders.id_produc
                    join vid on vid.id_vid  = product.id_vid
                    order by  orders.date desc   ';
                $result = $this->db->query($sql,array());

    } 
           return $result->result_array();
   

  }
}
