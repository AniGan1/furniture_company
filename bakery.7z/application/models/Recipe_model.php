<?php
class Recipe_model extends CI_Model{
 
    public function add_recipe($name_produc){
           $sql = 'insert into recipe(name_produc) values(?)';
           $result = $this->db->query($sql,array($name_produc));
           return $this->db->insert_id();
    }


    public function add_ingredients($id_recipe, $ings, $counts){
        for($i=0;$i<count($ings);$i++){
            $sql = 'insert into detal_recipe(id_recipe,id_ingred,col) values(?,?,?)';
           $result = $this->db->query($sql,array($id_recipe,$ings[$i],$counts[$i]));
        }
        return true;
    }
    
    public function get_all(){
           $sql = 'select * from recipe';
           $result = $this->db->query($sql,array());
           $data = $result->result_array();
           $r = [];
           $i = 0;
           foreach($data as $d){
                $ings = $this->db->query('select * from detal_recipe join ingredient on ingredient.id_ingred =detal_recipe.id_ingred  where id_recipe = ?',array($d['id_recipe']));
                $item = [];
                $item['name'] =  $d['name_produc'];
                $item['id_recipe'] =  $d['id_recipe'];
                $item['date'] = $d['date'];;
                $item['items'] = $ings->result_array();
                $r[] = $item;
                $i++;
            }
           return $r;
    }

    public function delete_recipe($id_recipe){
         $sql = 'delete from recipe where id_recipe  = ?';
           $result = $this->db->query($sql,array($id_recipe));
           return true;
    }
    


}
