<?php
class Ingredient_model extends CI_Model{
 
    public function get_ingredient(){
           $sql = 'select * from ingredient';
           $result = $this->db->query($sql,array());
           return $result->result_array();
    }

    public function delete_detail($id_detal){
            $sql = 'delete from detal_recipe where id_detal = ?';
           $result = $this->db->query($sql,array($id_detal));
           return true;
    }

    public function delete_detail_id_recipe($id_recipe){
         $sql = 'delete from detal_recipe where id_recipe  = ?';
           $result = $this->db->query($sql,array($id_recipe));
           return true;
    }
}
