<?php
class User_model extends CI_Model{
    public function users_reg($fio, $login, $adres, $password, $phone){
        $sql = 'insert into users(fio, adres, phone, login, password) values (?,?,?,?,?)';
        
        $result = $this->db->query($sql,array($fio, $adres, $phone, $login, $password));
        return $this->db->insert_id();
    }

    public function users_auto($login, $password){
        $sql = 'select * from users where login = ? and password = ?';
        $result = $this->db->query($sql,[$login, $password]);
        return $result->row_array();
    }
}
?>