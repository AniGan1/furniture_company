<?php
class Task_model extends CI_Model{
 
    public function add_task($date){
           $sql = 'insert into task(status,date) values("Не выполнено", ?)';
           $result = $this->db->query($sql,array($date));
           return $this->db->insert_id();
    }


    public function add_products($id_task, $products, $counts, $unit){
        for($i=0;$i<count($products);$i++){
            $sql = 'insert into detal_task(id_task,id_prodc ,col,unit) values(?,?,?,?)';
           $result = $this->db->query($sql,array($id_task,$products[$i],$counts[$i],$unit));
        }
        return true;
    }

    
    public function get_all(){
           $sql = 'select * from task';
           $result = $this->db->query($sql,array());
           $data = $result->result_array();
           $r = [];
           $i = 0;
           foreach($data as $d){
                $ings = $this->db->query('select detal_task.*, product.name_produc,product.unit, product.price from detal_task
                     join product on product.id_produc = detal_task.id_prodc  where id_task  = ?',array($d['id_task']));
                $item = [];
                $item['status'] =  $d['status'];
                $item['date'] = $d['date'];;
                $item['items'] = $ings->result_array();
                $r[] = $item;
                $i++;
            }
           
           return $r;
    }
    


}
