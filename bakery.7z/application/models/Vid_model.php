<?php
class Vid_model extends CI_Model{

    public function get_vid(){
        $sql = 'select * from vid';
        $result = $this->db->query($sql);
        return $result->result_array();
   }

}
