<?php
class Client_model extends CI_Model{

    public function check_order($id_user, $id_product, $col, $oplata,$id_contact,$datetime){
           $sql = 'insert into orders(col, id_user , id_produc,oplata,id_contract,date  ) values(?, ?, ?,?,?,?)';
           $result = $this->db->query($sql,array($col, $id_user, $id_product,$oplata,$id_contact,$datetime));
           return $this->db->insert_id();
    } 

    public function get_clients($phone=false){
        $sql = 'select * from users where role="client"';
        if($phone){
            $sql .= ' and phone = ?';
            $result = $this->db->query($sql,array($phone));

        }else{
            $result = $this->db->query($sql,array());

        }
           return $result->result_array();
    }
 
  
}
