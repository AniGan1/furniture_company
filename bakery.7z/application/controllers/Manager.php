<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Manager extends CI_Controller{
    public function orders(){
        $this->load->model('order_model');
        if(isset($_GET['filter'])){
            $date = $_GET['date'];
            $name_product = $_GET['name_product'];
            $fio_client = $_GET['fio_client'];
            $data['products'] = $this->order_model->orders_select($date,$name_product,$fio_client);
 
        }else{
            $data['products'] = $this->order_model->orders_select();

        }
        if(isset($_POST['update_status'])){
            $id_order = $_POST['id_order'];
            $status = $_POST['status'];
             $this->order_model->edit_order_status($id_order,$status);
             redirect('/manager/orders');
        }
        $this->load->view('temp/header.php');
        $this->load->view('temp/manager_nav.php');
        //$this->load->model('vid_model');
        //$data['vids'] = $this->vid_model->get_vid();
        $this->load->view('manager/orders.php', $data);
        $this->load->view('temp/footer.php');
    }
public function new_product(){
        $this->load->model('vid_model');
        $this->load->model('product_model');
        $data['vids'] = $this->vid_model->get_vid();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name_produc = trim($_POST['name_produc'] ?? '');
            $col = intval($_POST['col'] ?? 0);
            $width = floatval($_POST['width'] ?? 0);
            $unit = trim($_POST['unit'] ?? '');
            $price = floatval($_POST['price'] ?? 0);
            $id_vid = intval($_POST['vid'] ?? 0);
            $img = $_POST['img'] ?? '';
            $this->product_model->add_product($name_produc, $col, $width, $unit, $price, $id_vid,$img);

        }
        $data['products'] = $this->product_model->get_all();
        $this->load->view('temp/header.php');
        $this->load->view('temp/manager_nav.php');
       
        $this->load->view('manager/new_product.php', $data);
        $this->load->view('temp/footer.php');
    }

    public function sales_report(){
        $this->load->model('order_model');
         if(isset($_GET['filter'])){
            $start_date = $_GET['start_date'];
            $end_date = $_GET['end_date'];
            //$data['products'] = $this->order_model->analiz_products($start_date, $end_date);
            $data['sales'] = $this->order_model->report_sales($start_date, $end_date);

       }else{
            $data['sales'] = $this->order_model->report_sales();

       }
        
        $this->load->view('temp/header.php');
        $this->load->view('temp/manager_nav.php');
       
        $this->load->view('manager/sales_report.php', $data);
        $this->load->view('temp/footer.php');
    }
   
  
}
?>