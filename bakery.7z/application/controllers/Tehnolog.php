<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Tehnolog extends CI_Controller{
    public function create_recipe(){
        $this->load->model('ingredient_model');
        $this->load->model('recipe_model');
        if(isset($_POST['delete_ingr'])){
            $id_detal = $_POST['id_detal'];
            $this->ingredient_model->delete_detail($id_detal);
        }

         if(isset($_POST['recipe_deleter'])){
            $id_recipe = $_POST['id_recipe'];
            $this->ingredient_model->delete_detail_id_recipe($id_recipe);
            $this->recipe_model->delete_recipe($id_recipe);

        }


        
        $data['recipts'] = $this->recipe_model->get_all();
        $data['ingredients'] = $this->ingredient_model->get_ingredient();
        $this->load->view('temp/header.php');
        $this->load->view('temp/tehnolog_nav.php');
        $this->load->view('tehnolog/create_recipe.php', $data);
        $this->load->view('temp/footer.php');
    }
 
    public function create_task(){
        $this->load->model('product_model');
        $this->load->model('task_model');
        $data['tasks'] = $this->task_model->get_all();
        $data['products'] = $this->product_model->get_all();
        $this->load->view('temp/header.php');
        $this->load->view('temp/tehnolog_nav.php');
        $this->load->view('tehnolog/create_task.php', $data);
        $this->load->view('temp/footer.php');

    }

    public function add_product(){
        $this->load->model('recipe_model');
        $data = $_POST;
        $product_name = $data['productName'];
        $ingredients = $data['ingredients'];
        $counts = $data['counts'];
        $id_recipe = $this->recipe_model->add_recipe($product_name);
        $this->recipe_model->add_ingredients($id_recipe, $ingredients, $counts);
        redirect('tehnolog/create_recipe');
    }


    public function add_task(){
        $this->load->model('task_model');
        $data = $_POST;
        $date = $data['date'];
        $ed = $data['ed'];
        $counts = $data['counts'];
        $products = $data['products'];
        $id_task = $this->task_model->add_task($date);
        $this->task_model->add_products($id_task, $products, $counts, $ed);
        redirect('tehnolog/create_task');
    }

}
?>