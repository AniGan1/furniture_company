<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Client extends CI_Controller{
    public function index(){
        $this->load->model('product_model');
        if(isset($_GET['filter'])){
            $vid = $_GET['vid'];
            $sort = $_GET['sort'];
            $data['products'] = $this->product_model->product_select($vid, $sort);

        }else{
            $data['products'] = $this->product_model->product_select();

        }
        $this->load->view('temp/header.php');
        $this->load->view('temp/client_nav.php');
        $this->load->model('vid_model');
        $data['vids'] = $this->vid_model->get_vid();
        $this->load->view('client/index.php', $data);
        $this->load->view('temp/footer.php');
    }

    public function orders(){
        $this->load->view('temp/header.php');
        $this->load->view('temp/client_nav.php');
        $this->load->model('order_model');
        $data['orders'] = $this->order_model->get_order_by_user($_SESSION['user_id']);
        $this->load->view('client/orders.php', $data);
        $this->load->view('temp/footer.php');
    }

    public function check_order(){
        $id_user = $_SESSION['user_id'];
        $id_product = $_POST['id_product'];
        $col = $_POST['quantity'];
        $oplata = $_POST['oplata'];
        $datetime = $_POST['datetime'];
        $this->load->model('client_model');
        $this->load->model('product_model');
        $this->load->model('contract_model');
        $id_contact = $this->contract_model->add_contact($id_user, 'Доставка', $oplata);
 
        $this->client_model->check_order($id_user, $id_product, $col,$oplata, $id_contact,$datetime);
        $this->product_model->update_col_product($id_product, $col);

        redirect('client/orders');
    }


    public function delete_order(){
            
        $id_order = $_POST['id_order'];
        $this->load->model('order_model');

        $this->order_model->delete_order($id_order);

        
        redirect('client/orders');
    }

    public function edit_order(){

        $id_order = $_POST['id_order'];
        $date = $_POST['date'];
        $col = $_POST['col'];
        $this->load->model('order_model');

        $this->order_model->edit_order($id_order, $date, $col);

        
        redirect('client/orders');
    }
}
?>