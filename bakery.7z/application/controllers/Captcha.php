<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Captcha extends CI_Controller {
    public function __construct() {
        parent::__construct();
        if (!extension_loaded('gd')) {
            show_error('GD library is not loaded');
        }
    }
    
    public function index() {
        $this->load->library('simple_captcha');
        $this->simple_captcha->generate();
        exit; 
    }
}