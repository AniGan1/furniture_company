<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller{
    public function index(){
        $this->load->view('temp/header.php');
        $this->load->view('temp/navbar.php');
        $this->load->model('product_model');
        $data['products'] = $this->product_model->product_select();
        $this->load->view('index.php', $data);
        $this->load->view('temp/footer.php');
    }   

    public function reg(){
        $this->load->view('temp/header.php');
        $this->load->view('temp/navbar.php');
        $this->load->view('user/reg.php');
        $this->load->view('temp/footer.php');
    }

    public function auto(){
        $this->load->view('temp/header.php');
        $this->load->view('temp/navbar.php');
        $this->load->view('user/auto.php');
        $this->load->view('temp/footer.php');
    }

    public function checkPasswordStrength($password) {
        $strength = 0;
        $feedback = [];

        if (strlen($password) < 8) {
            $feedback[] = "Пароль должен содержать минимум 8 символов";
        } else {
            $strength += 1;
        }

        if (!preg_match('/[0-9]/', $password)) {
            $feedback[] = "Добавьте хотя бы одну цифру";
        } else {
            $strength += 1;
        }

        if (!preg_match('/[A-ZА-Я]/u', $password)) {
            $feedback[] = "Добавьте хотя бы одну заглавную букву";
        } else {
            $strength += 1;
        }

        if (!preg_match('/[a-zа-я]/u', $password)) {
            $feedback[] = "Добавьте хотя бы одну строчную букву";
        } else {
            $strength += 1;
        }

        if (!preg_match('/[^a-zA-Z0-9а-яА-Я]/u', $password)) {
            $feedback[] = "Добавьте хотя бы один специальный символ (!@#$%^&* и т.д.)";
        } else {
            $strength += 1;
        }

        $rating = "";
        if ($strength < 3) {
            $rating = "Очень слабый";
        } elseif ($strength == 3) {
            $rating = "Слабый";
        } elseif ($strength == 4) {
            $rating = "Средний";
        } else {
            $rating = "Сильный";
        }

        return [
            'strength' => $strength,
            'rating' => $rating,
            'feedback' => $feedback
        ];
    }

    public function check_reg(){
        if(!empty($_POST)){
            $this->load->library('simple_captcha');
            $input = $this->input->post('captcha');
             if ($this->simple_captcha->validate($input)) {
                $fio = strip_tags(htmlspecialchars($this->input->post('fio', TRUE)));
                $adres = strip_tags(htmlspecialchars($this->input->post('adres', TRUE)));
                $login = strip_tags(htmlspecialchars($this->input->post('login', TRUE)));
                $password = strip_tags(htmlspecialchars($this->input->post('password', TRUE)));
                if (empty($fio) || empty($adres) || empty($login)) {
                    $this->session->set_flashdata('password_error', 'Заполните все поля!');

                    redirect('main/reg');
                }
                
                $result = $this->checkPasswordStrength($password);
                if($result['strength'] < 4){
                    $message_error = '';
                    if (!empty($result['feedback'])) {
                        foreach ($result['feedback'] as $message) {
                            $message_error .= $message . "<br />";
                        }
                    }
       
                    $this->session->set_flashdata('password_error', $message_error);
                    redirect('main/reg');
                }
                
                $phone = htmlspecialchars($_POST['phone']);
                $this->load->model('user_model');
                $data['user'] = $this->user_model->users_reg($fio, $login, $adres, $password, $phone); 
                redirect('main/auto');
            } else {
                $this->session->set_flashdata('captcha_error', 'Неверно введена CAPTCHA!');
                redirect('main/reg');
            }
            
        }
    }

    public function check_auto(){
        if(!empty($_POST)){ 
             $this->load->library('simple_captcha');
            $input = $this->input->post('captcha');
             if ($this->simple_captcha->validate($input)) {
                $login = $_POST['login'];
                $password = $_POST['password'];
                
                $this->load->model('user_model');
                $user = $this->user_model->users_auto($login, $password);
                if($user && $password){
                    $user_data = [
                        'user_id' => $user['id_user'],
                        'login' => $user['login'],
                        'role' => $user['role']
                    ];
                    $role = $user['role'];
                    $this->session->set_userdata($user_data);
                    if($role == 'client'){
                        redirect('client/index');
                    }elseif($role == 'tehnolog'){
                        redirect('tehnolog/create_recipe');
                    }
                    elseif($role == 'manager'){
                        redirect('manager/orders');
                    }
                    elseif($role == 'admin'){
                        redirect('admin/price_list');
                    }else{
                        redirect('client/index');
                    }
                
                }else{
                    $this->session->set_flashdata('error', 'Неверный логин или пароль');
                }
            redirect('main/auto');
        }else{
                $this->session->set_flashdata('captcha_error', 'Неверно введена CAPTCHA!');
                redirect('main/auto');
        }
        }
    }

    public function logout(){
        $this->session->sess_destroy();
        redirect('Main/index');
    }
}
?>