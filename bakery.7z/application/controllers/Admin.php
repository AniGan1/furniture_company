<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Admin extends CI_Controller{
    public function price_list(){
        $this->load->model('product_model');
       if(isset($_GET['filter'])){
            $date = $_GET['date'];
            $data['products'] = $this->product_model->get_all_select($date);

       }else{
                $data['products'] = $this->product_model->get_all_select(false);

       }
        $this->load->view('temp/header.php');
        $this->load->view('temp/admin_nav.php');
        $this->load->view('admin/price_list.php', $data);
        $this->load->view('temp/footer.php');
    }


    public function analiz(){
 $this->load->model('order_model');
       if(isset($_GET['filter'])){
            $start_date = $_GET['start_date'];
            $end_date = $_GET['end_date'];
            $data['products'] = $this->order_model->analiz_products($start_date, $end_date);

       }else{
            $data['products'] = $this->order_model->analiz_products();

       }
        $this->load->view('temp/header.php');
        $this->load->view('temp/admin_nav.php');
        $this->load->view('admin/analiz.php', $data);
        $this->load->view('temp/footer.php');
    }

    public function clients(){
    $this->load->model('client_model');
       if(isset($_GET['filter'])){
            $phone = $_GET['phone'];
            $data['clients'] = $this->client_model->get_clients($phone);

       }else{
           $data['clients'] = $this->client_model->get_clients();

       }
        $this->load->view('temp/header.php');
        $this->load->view('temp/admin_nav.php');
        $this->load->view('admin/clients.php', $data);
        $this->load->view('temp/footer.php');
    }


    public function history_orders(){
 $this->load->model('order_model');
       if(isset($_GET['filter'])){
            $start_date = $_GET['start_date'];
            $end_date = $_GET['end_date'];
            $data['orders'] = $this->order_model->history_orders($start_date, $end_date);

       }else{
            $data['orders'] = $this->order_model->history_orders();

       }
        $this->load->view('temp/header.php');
        $this->load->view('temp/admin_nav.php');
        $this->load->view('admin/history_orders.php', $data);
        $this->load->view('temp/footer.php');
    }
}
?>