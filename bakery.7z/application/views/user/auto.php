<div class="container mt-5">
  <?php if($this->session->flashdata('error')): ?>
    <div class="alert alert-danger">
        <?php echo $this->session->flashdata('error'); ?>
    </div>
<?php endif; ?>
<?php if ($this->session->flashdata('captcha_error')): ?>
    <div class="alert alert-danger">
        <?php echo $this->session->flashdata('captcha_error'); ?>
    </div>
<?php endif; ?>

<form method="POST" action="Main/check_auto">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Введите логин</label>
    <input required type="text" name="login" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Введите пароль</label>
    <input required type="password" name="password" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
   <div class="mb-3">
    <img src="<?= base_url('captcha') ?>" onclick="this.src='<?= base_url('captcha') ?>?'+Math.random()" style="cursor: pointer;">

    <input type="text" name="captcha" required>
  </div>
  <button type="submit" name="auto" class="btn btn-primary">Авторизация</button>
</form>
</div>