<div class="container mt-5">
  <?php if ($this->session->flashdata('captcha_error')): ?>
    <div class="alert alert-danger">
        <?php echo $this->session->flashdata('captcha_error'); ?>
    </div>
<?php endif; ?>
<div class="container mt-5">
  <?php if ($this->session->flashdata('password_error')): ?>
    <div class="alert alert-danger">
        <?php echo $this->session->flashdata('password_error'); ?>
    </div>
<?php endif; ?>

<form method="POST" action="Main/check_reg" enctype="multipart/form-data">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Введите Ф.И.О</label>
    <input required type="text" name="fio" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Введите адрес</label>
    <input required type="text" name="adres" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Введите телефон</label>
    <input required type="text" name="phone" class="form-control" id="phoneInput" aria-describedby="emailHelp">
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Введите логин</label>
    <input required type="text" name="login" class="form-control" id="login_input" aria-describedby="emailHelp">
  </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Введите пароль</label>
    <input required type="password" name="password" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="mb-3">
    <img src="<?= base_url('captcha') ?>" onclick="this.src='<?= base_url('captcha') ?>?'+Math.random()" style="cursor: pointer;">
    <input type="text" name="captcha" required>
  </div>
  <button type="submit" name="reg" id="reg" class="btn btn-primary">Регистрация</button>
</form>
</div> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/5.0.6/jquery.inputmask.min.js"></script>
<script>
$(document).ready(function(){
    $('#phoneInput').inputmask('+7 (999) 999-99-99');
});
function validateLogin(login) {
    if (login.length < 4 || login.length > 20) {
        return false;
    }
    
    const regex = /^[a-zA-Z0-9_]+$/;
    return regex.test(login);
}
$('#reg').on('click', function(){
  let login = $('#login_input').val();
  if (!validateLogin(login)) {
    alert('Некорректный логин!');
  }
});
</script>