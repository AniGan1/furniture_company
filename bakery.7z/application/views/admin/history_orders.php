<div class="container mt-4">
    <h3 class="text-center">Фильтр</h3>
    <form class='row align-items-center' method="get">
  <div class="col-3">
    <p>Дата от</p>
    <p>
        <?php
        $start_date = isset($_GET["start_date"]) ? $_GET["start_date"]:false;
        ?>
        <input type="datetime-local" class="form-control" value="<?=$start_date?>" name="start_date" id="start_date">
    </p>
  </div>
  <div class="col-3">
    <p>Дата до</p>
    <p>
        <?php
        $end_date = isset($_GET["end_date"]) ? $_GET["end_date"]:false;
        ?>
        <input type="datetime-local" class="form-control" value="<?=$end_date?>" name="end_date" id="end_date">
    </p>
  </div>
  <div class="col-3">
    <button type="submit" name="filter" class="btn btn-primary">Найти</button>
  </div>
</form>
</div>
<div class="container">
    <h2 class="text-center">История заказов клиентов</h2>
<table class="table">
    <tr>
      <th>Дата</th>
      <th>Вид продукции</th>
      <th>Наименование товара</th>
      <th>Единица измерения</th>
      <th>Количество</th>
      <th>Цена</th>
      <th>Сумма</th>
    </tr>
    <? foreach($orders as $order):?>
    <tr>
      <td><?=$order['date']?></td>
      <td><?=$order['name_vid']?></td>
      <td><?=$order['name_produc']?></td>
      <td><?=$order['unit']?></td>
      <td><?=$order['col']?></td>
      <td><?=$order['price']?></td>
      <td><?=($order['col']*$order['price'])?></td>
    </tr>
    <? endforeach;?>
</table>
</div>