  <div class="container mt-4">
    <h3>Фильтр</h3>
    <form class='row align-items-center' method="get">  
        <div class="col-3">
            <p>Дата</p>
            <p>
            <?php 
            $date = isset($_GET['date'])?$_GET['date']:false;       
            ?>
            <input class="form-control" value="<?=$date?>" type="datetime-local" name="date" id="date"></p>
        </div>       
         <div class="col-3">
            <button type="submit" class="btn btn-primary" name="filter">Найти</button>
        </div>
    </form>
 </div>
 <div class="container">
    <h2 class="text-center">Прайс-лист</h2>
    <table class="table">
        <tr>
            <th>Вид продукции</th>
            <th>Наименование товара</th>
            <th>Дата</th>
            <th>Цена</th>          
        </tr>
        <? foreach($products as $product): ?>
        <tr>
            <td><?=$product['name_vid']?></td>
            <td><?=$product['name_produc']?></td>
            <td><?=$product['created_at']?></td>
            <td><?=$product['price']?> руб.</td>            
        </tr>
        <? endforeach; ?>
    </table>
 </div>
