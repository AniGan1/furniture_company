<div>
  <h3 class="text-center">Фильтр</h3>
  <form class='row align-items-center justify-content-center' method="get">
  <div class="col-3">
    <p>Номер телефона</p>
    <p><input type="text" class="form-control" name="phone" id="phone"></p>
  </div>
  <div class="col-3">
    <button type="submit" name="filter" class="btn btn-primary">Найти</button>
  </div>
</form>
</div>
<div class="container">
    <h2 class="text-center">Список клиентов</h2>
<table class="table">
    <tr>
      <th scope="col">Наименование заказчика</th>
      <th scope="col">ИНН заказчика</th>
      <th scope="col">Адрес</th>
      <th scope="col">Телефон</th>
    </tr>
    <? foreach($clients as $client):?>
    <tr>
      <td><?=$client['fio']?></td>
      <td><?=$client['inn']?></td>
      <td><?=$client['adres']?></td>
      <td><?=$client['phone']?></td>
    </tr>
    <? endforeach;?>
</table>
</div>