<div class="container mt-4">
<h3>Фильтр</h3>
<form class='row align-items-center' method="get">
  <div class="col-3">
    <p>Дата от</p>
    <p>
        <?php
        $start_date = isset($_GET["start_date"]) ? $_GET["start_date"]:false;
        ?>
        <input type="datetime-local" class="form-control" value="<?=$start_date?>" name="start_date" id="start_date">
    </p>
  </div>
  <div class="col-3">
    <p>Дата до</p>
    <p>
        <?php
        $end_date = isset($_GET["end_date"]) ? $_GET["end_date"]:false;
        ?>
        <input type="datetime-local" class="form-control" value="<?=$end_date?>" name="end_date" id="end_date">
    </p>
  </div>
  <div class="col-3">
    <button type="submit" name="filter" class="btn btn-primary">Найти</button>
  </div>
</form>
</div>
<div class="container">
    <h2 class="text-center">Анализ спроса продукции</h2>
<table class="table">
    <tr>
      <th scope="col">Вид продукции</th>
      <th scope="col">Наименование товара</th>
      <th scope="col">Единица измерения</th>
      <th scope="col">Количество</th>
      <th scope="col">Цена</th>
      <th scope="col">Сумма</th>
      <th scope="col">Дата</th>
    </tr>
    <? foreach($products as $product):?>
    <tr>
      <td><?=$product['name_vid']?></td>
      <td><?=$product['name_produc']?></td>
      <td><?=$product['unit']?></td>
      <td><?=$product['col']?></td>
      <td><?=$product['price']?></td>
      <td><?=($product['col']*$product['price'])?></td>
      <td><?=$product['date']?></td>
    </tr>
    <? endforeach;?>
</table>
</div>