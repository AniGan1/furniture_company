<div class="container m-4">
    <h2 сlass='m-4'>Добавить</h2>
     <form id="productForm" action="tehnolog/add_product" method='post'>
            <div class="mb-3">
                <label for="productName" class="form-label">Название товара</label>
                <input type="text" class="form-control" name='productName' id="productName" required>
            </div>
 <div class="mb-3">
                <label class="form-label">Ингридиенты</label>
                <div id="ingredientsContainer">
                    <div class="input-group mb-2 ingredient-group">
                        <select class="form-control ingredient-input" name="ingredients[]">
                            <?php foreach($ingredients as $ing): ?>
                                <option value='<?=$ing['id_ingred']?>'><?=$ing['name_ingred']?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type='number' value="1" name='counts[]' class='form-control'>

                        <button type="button" class="btn btn-outline-danger remove-ingredient">Удалить</button>
                    </div>
                </div>
                <button type="button" id="addIngredient" class="btn btn-outline-primary mt-2">Добавить Ингридиент</button>
                            </div>
                                        <div class="mb-3">

                <button type="submit" class="btn btn-success">Добавить</button>
                            </div>
            </form>

</div>
<?php 
$r = '<select class="form-control ingredient-input" name="ingredients[]">';

?>
                            <?php foreach($ingredients as $ing): ?>
                                <?php $r .= '<option value='.$ing["id_ingred"].'>'.$ing['name_ingred'].'</option>'; ?>
                            <?php endforeach; ?>
                        <?php $r .= '</select>';

?>



<script>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('addIngredient').addEventListener('click', function() {
                const container = document.getElementById('ingredientsContainer');
                const newIngredientGroup = document.createElement('div');
                newIngredientGroup.className = 'input-group mb-2 ingredient-group';
                newIngredientGroup.innerHTML = `
                    <?=$r?>
                    <input type='number' value="1" name='counts[]' class='form-control'>

                    <button type="button" class="btn btn-outline-danger remove-ingredient">Удалить</button>
                `;
                container.appendChild(newIngredientGroup);
                
                newIngredientGroup.querySelector('.remove-ingredient').addEventListener('click', function() {
                    container.removeChild(newIngredientGroup);
                });
            });
            
    
            
            document.querySelector('.remove-ingredient').addEventListener('click', function() {
                if (document.querySelectorAll('.ingredient-group').length > 1) {
                    this.closest('.ingredient-group').remove();
                }
            });
        });
    </script>

<div class="container">
    <h4 class="mb-4">Список рецептов</h4>
     <?php foreach ($recipts as $recipe): ?>
            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h3><?= htmlspecialchars($recipe['name']) ?></h3>
                    <p class="text-muted mb-0">Дата: <?= htmlspecialchars($recipe['date']) ?></p>
                     <form method="post">
                        <input type="hidden" name="id_recipe" value="<?=$recipe['id_recipe']?>">
                        <button type="submit" class="btn btn-danger" name="recipe_deleter">Удалить</button>
                    </form>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Ингредиент</th>
                                <th>Количество</th>
                                <th>Ед. измерения</th>
                                <th>Остаток на складе</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recipe['items'] as $index => $item): ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td><?= htmlspecialchars($item['name_ingred']) ?></td>
                                    <td><?= htmlspecialchars($item['col']) ?></td>
                                    <td><?= htmlspecialchars($item['unit']) ?></td>
                                    <td><?= htmlspecialchars($item['stocks']) ?></td>
                                    <td>
                                        <form method="post">
                                            <input type="hidden" name="id_detal" value="<?=$item['id_detal']?>">
                                            <button type="submit" class="btn btn-danger" name="delete_ingr">Удалить</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endforeach; ?>
</div> 