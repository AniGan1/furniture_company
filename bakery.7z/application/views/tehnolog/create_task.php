<div class="container m-4">
    <h2 сlass='m-4'>Добавить</h2>
     <form id="productForm" action="tehnolog/add_task" method='post'>
            <div class="mb-3">
                <label for="date" class="form-label">Дата</label>
                <input type="date" class="form-control" name='date' id="date" required>
            </div>
            <div class="mb-3">
                <label for="ed" class="form-label">Единица измерения</label>
                <input type="text" class="form-control" name='ed' id="ed" required>
            </div>
 <div class="mb-3">
                <label class="form-label">Продукция</label>
                <div id="productContainer">
                    <div class="input-group mb-2 product-group">
                        <select class="form-control product-input" name="products[]">
                            <?php foreach($products as $product): ?>
                                <option value='<?=$product['id_produc']?>'><?=$product['name_produc']?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type='number' value="1" name='counts[]' class='form-control'>

                        <button type="button" class="btn btn-outline-danger remove-ingredient">Удалить</button>
                    </div>
                </div>
                <button type="button" id="addProduct" class="btn btn-outline-primary mt-2">Добавить товар</button>
                            </div>
                                        <div class="mb-3">

                <button type="submit" class="btn btn-success">Добавить</button>
                            </div>
            </form>

</div>
<?php 
$r = '<select class="form-control ingredient-input" name="products[]">';

?>
                            <?php foreach($products as $product): ?>
                                <?php $r .= '<option value='.$product["id_produc"].'>'.$product['name_produc'].'</option>'; ?>
                            <?php endforeach; ?>
                        <?php $r .= '</select>';

?>



<script>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('addProduct').addEventListener('click', function() {
                const container = document.getElementById('productContainer');
                const newIngredientGroup = document.createElement('div');
                newIngredientGroup.className = 'input-group mb-2 product-group';
                newIngredientGroup.innerHTML = `
                    <?=$r?>
                    <input type='number' value="1" name='counts[]' class='form-control'>

                    <button type="button" class="btn btn-outline-danger remove-ingredient">Удалить</button>
                `;
                container.appendChild(newIngredientGroup);
                
                newIngredientGroup.querySelector('.remove-ingredient').addEventListener('click', function() {
                    container.removeChild(newIngredientGroup);
                });
            });
            
    
            
            document.querySelector('.remove-ingredient').addEventListener('click', function() {
                if (document.querySelectorAll('.product-group').length > 1) {
                    this.closest('.product-group').remove();
                }
            });
        });
    </script>


</div>


<div class="container">
    <h4 class="mb-4">Список заданий</h4>
     <?php foreach ($tasks as $task): ?>
            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h3><?=$task['status']?> </h3>
                    <p class="text-muted mb-0">Дата: <?= htmlspecialchars($task['date']) ?></p>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Название товара</th>
                                <th>Количество</th>
                                <th>Ед. измерения</th>
                                <th>Цена</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($task['items'] as $index => $item): ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td><?= htmlspecialchars($item['name_produc']) ?></td>
                                    <td><?= htmlspecialchars($item['col']) ?></td>
                                    <td><?= htmlspecialchars($item['unit']) ?></td>
                                    <td><?= htmlspecialchars($item['price']) ?></td>

                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endforeach; ?>
</div>