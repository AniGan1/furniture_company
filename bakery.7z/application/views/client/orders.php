<div class="container mt-5">
    <?php if($orders): ?>
<table class="table table-striped table-borded mt-5">
    <thead class="table-success">
        <tr>
            <th>Название товара</th>
            <th>Цена</th>
            <th>Адрес</th>
            <th>Коичество</th>
            <th>Вид опаты</th>
            <th>Дата</th>
            <th>Статус</th>
            <th></th>
                        <th></th>

        </tr>
        </thead>
        <tbody>

        <?php foreach($orders as $order): ?>
            <tr><td><?=$order['name_produc']?></td>
            <td><?=$order['price']?></td>
            <td><?=$order['adres']?></td>
           <td><?=$order['col']?></td>
            <td><?=$order['oplata']?></td>
            <td><?=$order['date']?></td>
            <td><?=$order['status']?></td>
            <td>
                    <a href='#' data-bs-toggle="modal" data-bs-target="#editOrderModal" class="btn btn-success" onclick='editOrder(<?=$order["col"]?>,"<?=$order["date"]?>", <?=$order["id_order"]?>)'>Редактировать</button>
               </td>
                  <td><form action="/client/delete_order" method="post">
                    <input type="hidden" name="id_order" value='<?=$order['id_order']?>'>
                    <button type="submit" class="btn btn-danger">Отменить</button>
                </form>
            </td>
        </tr>
       
        <?php endforeach; ?>
    </tbody>
</table>
<?php else: ?>
    <div class="alert alert-danger">Нет заказов</div>
<?php endif; ?>
</div>