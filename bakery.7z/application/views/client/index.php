 <div class="container mt-4">
 <form  method="get">
 <div class="row justify-content-center">
    <div class="col-2">
    <select class="form-control" name='vid'> 
      <option value="0">Не выбран</option> 
    <?php foreach($vids as $vid): ?>
        <?php if (isset($_GET['vid']) && $_GET['vid'] == $vid['id_vid']): ?>
        <option value="<?=$vid['id_vid']?>" selected><?=$vid['name_vid']?></option>

          <? else: ?>
        <option value="<?=$vid['id_vid']?>"><?=$vid['name_vid']?></option>

            <?php endif; ?>
      <?php endforeach; ?>
    </select>
    </div>
    <div class="col-2">
    <select class="form-control" name='sort'>  
        <?php if (isset($_GET['sort']) && $_GET['sort'] == 'asc'): ?>
<option value="asc" selected>По цене возрастанию</option>
        <option value="desc">По цене убывание</option>


          <?php else: ?>
<option value="asc">По цене возрастанию</option>
        <option value="desc" selected>По цене убывание</option>

            <?php endif; ?>
        
    </select>
    </div>
    <div class="col-2">
          <button class="btn btn-success" type="submit" name='filter'>Найти</button>

    </div>
 </div>
  </div>
  </form>
 
 <div class="row justify-content-center mt-4">
    <?php foreach($products as $product): ?>
    <div class="card m-3" style="width: 18rem;">
  <div class="card-body">
    <p>
      <img src="<?=$product['img']?>" width="100%" alt="">
    </p>
    <h5 class="card-title"><?=$product['name_produc']?></h5>
    <p class="card-text"><b>Категория: </b><?=$product['name_vid']?><br /><b>Цена: </b><?=$product['price']?> руб.</p>
    <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal" class="btn btn-primary" onclick='startData(<?=$product["col"]?>, <?=$product["width"]?>, "<?=$product["unit"]?>")'>Подробнее</a>
    <a href="#" data-bs-toggle="modal" data-bs-target="#exampleOrderModal" class="btn btn-success" onclick='orderData(<?=$product["id_produc"]?>, <?=$product["col"]?>)'>Заказать</a>
   
</div> 
</div>
<?php endforeach; ?>
</div>