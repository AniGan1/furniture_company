 <div class="container mt-5">
        <h2 class="mb-4 text-center">Добавление нового товара</h2>
        <form  method="POST" class="row mb-3 justify-content-center"  >
        <div style="width: 500px;">       
        <div class="col-md-12">
                    <label for="name_produc" class="form-label">Наименование товара</label>
                    <input type="text" class="form-control" id="name_produc" name="name_produc" required maxlength="30">
                </div>
                <div class="col-md-12">
                    <label for="col" class="form-label">Количество</label>
                    <input type="number" class="form-control" id="col" name="col" required>
                </div>
                <div class="col-md-12">
                    <label for="width" class="form-label">Вес продукции</label>
                    <input type="number" step="0.01" class="form-control" id="width" name="width" required>
                </div>
                <div class="col-md-12">
                    <label for="unit" class="form-label">Единица измерения</label>
                    <input type="text" class="form-control" id="unit" name="unit" required maxlength="10">
                </div>
                <div class="col-md-12">
                    <label for="price" class="form-label">Цена</label>
                    <input type="number" class="form-control" id="price" name="price" required>
                </div>
         
             
      
                <div class="col-md-12">
                    <label for="id_vid" class="form-label">Вид продукции</label>
                        <select class="form-control" name="vid">
                            <? foreach($vids as $v): ?>
                                <option value="<?=$v['id_vid']?>"><?=$v['name_vid']?></option>
                            <? endforeach; ?>
                        </select>

                </div>
                <div class="col-md-12">
                    <label for="img" class="form-label">Картинка</label>
                    <input type="text" class="form-control" id="img" name="img" required>
                </div>
              
                <div class='d-flex justify-content-between'>
                <button type="submit" class="btn btn-primary">Добавить товар</button>
                <button type="reset" class="btn btn-secondary">Очистить</button>
            
                </div>
               </div> 
        </form>
    </div>


    <div class="container">
        <h2>Список товаров</h2>
        <table class="table"> 
            <tr class="bg-success text-white">
                <th>Название товара</th>
                <th>Количество</th>
                <th>Вес</th>
                <th>Единица измерения</th>
                <th>Цена</th>
                <th>Вид продукции</th>
            </tr>
            <? foreach($products as $product): ?>
             <tr>
                <th><?=$product['name_produc']?></th>
                <th><?=$product['col']?></th>
                <th><?=$product['width']?></th>
                <th><?=$product['unit']?></th>
                <th><?=$product['price']?></th>
                <th><?=$product['name_vid']?></th>
            </tr>
            <? endforeach; ?>
        </table>
    </div>