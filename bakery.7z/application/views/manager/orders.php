 <div class="container mt-4">
    <h3>Фильтр</h3>
    <form class='row align-items-center' method="get">  
        <div class="col-3">
            <p>Дата</p> 
            <? $date = isset($_GET['date'])?$_GET['date']:date('d-m-Y'); ?>
            <p><input class="form-control" type="date" name="date" value="<?=$date?>" id="date"></p>
        </div>
        <div class="col-3">
            <? $name_product = isset($_GET['name_product'])?$_GET['name_product']:''; ?>

            <p>Наименование продукции</p>
            <p><input class="form-control" type="text" name="name_product" value="<?=$name_product?>" id="name_product"></p>
        </div>
         <div class="col-3">
            <p>ФИО клиента</p>
                        <? $fio_client = isset($_GET['fio_client'])?$_GET['fio_client']:''; ?>

            <p><input class="form-control" type="text" name="fio_client" value="<?=$fio_client?>" id="fio_client"></p>
        </div>
         <div class="col-3">
            <button type="submit" class="btn btn-primary" name="filter">Найти</button>
        </div>
    </form>
 </div>
 <div class="container">
    <h2 class="text-center">Заказы клиентов</h2>
    <table class="table">
        <tr>
            <th>Дата</th>
            <th>Название товара</th>
            <th>Вид продукции</th>
            <th>Количество</th>
            <th>Цена</th>
            <th>ФИО клиента</th>
            <th>Сумма</th>
            <th>Статус</th>
        </tr>
        <? foreach($products as $product): ?>
        <tr>
            <td><?=$product['date']?></td>
            <td><?=$product['name_produc']?></td>
            <td><?=$product['name_vid']?><br /><?=$product['name_produc']?></td>
            <td><?=$product['count']?></td>
            <td><?=$product['price']?> руб.</td>
            <td><?=$product['fio']?></td>
            <td><?=($product['count']*$product['price'])?> руб.</td>
            <td>
                <form method="post">
                    <input type="hidden" name="id_product" value="<?=$product['id_order']?>">
                    <select name="status" class="form-control">
                        <? if ($product['status'] == 'Принят'): ?>
                            <option selected value="Принят">Принят</option>
                            <option value="Отправлен">Отправлен</option>
                        <? else: ?>
                            <option  value="Принят">Принят</option>
                            <option selected value="Отправлен">Отправлен</option>
                        <? endif; ?>
                        <input type="hidden" name="id_order" value="<?=$product['id_order']?>">
                    </select>  
                    <button type="submit" class="btn btn-secondary" name="update_status">Обновить</button>
                </form>  
        </tr>
        <? endforeach; ?>
    </table>
 </div>
