<div class="container mt-4">
<h3>Фильтр</h3>
<form class='row align-items-center' method="get">
  <div class="col-3">
    <p>Дата от</p>
    <p> 
        <?php
        $start_date = isset($_GET["start_date"]) ? $_GET["start_date"]:false;
        ?>
        <input type="datetime-local" class="form-control" value="<?=$start_date?>" name="start_date" id="start_date">
    </p>
  </div>
  <div class="col-3">
    <p>Дата до</p>
    <p>
        <?php
        $end_date = isset($_GET["end_date"]) ? $_GET["end_date"]:false;
        ?>
        <input type="datetime-local" class="form-control" value="<?=$end_date?>" name="end_date" id="end_date">
    </p>
  </div>
  <div class="col-3">
    <button type="submit" name="filter" class="btn btn-primary">Найти</button>
  </div>
</form>
</div>
<div class="container mt-4">
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h3>Отчет о продажах</h3>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>Наименование товара</th>
                            <th>Дата</th>
                            <th>Вид продукции</th>
                            <th>Количество</th>
                            <th>Сумма</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($sales as $item): ?>
                        <tr>
                            <td><?= $item['product_name'] ?></td>
                            <td><?= $item['date'] ?></td>
                             <td><?= $item['vid_name'] ?></td>
                            <td><?= $item['total_col'] ?></td>
                            <td><?= number_format($item['total_summa'], 2) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr class="table-info">
                            <td colspan="3" class="text-right"><strong>Итого:</strong></td>
                            <td><strong><?= number_format(array_sum(array_column($sales, 'total_summa')), 2) ?></strong></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
           
        </div>
    </div>
</div>