<div class="row justify-content-center mt-4">
    <?php foreach($products as $product): ?>
    <div class="card m-3" style="width: 18rem;">
  <div class="card-body">
    <p>
      <img src="<?=$product['img']?>" width="100%" alt="">
    </p>
    <h5 class="card-title"><?=$product['name_produc']?></h5>
    <p class="card-text"><b>Категория: </b><?=$product['name_vid']?><br /><b>Цена: </b><?=$product['price']?> руб.</p>
    <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal" class="btn btn-primary" onclick='startData(<?=$product["col"]?>, <?=$product["width"]?>, "<?=$product["unit"]?>")'>Подробнее</a>
  </div> 
</div>
<?php endforeach; ?>
</div>