<nav class="navbar navbar-expand-lg navbar-light bg-dark">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <img src="/public/img/logo.jpg" width="100px">
            <div class="collapse navbar-collapse justify-content-between" id="navbarNav">      
            <ul class="navbar-nav">
                <? if(isset($_SESSION['user_id'])): ?>
                          <li class="nav-item">
                        <a class="nav-link active text-light" aria-current="page" href="client/index">Главная</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active text-light" aria-current="page" href="client/orders">Мои заказы</a>
                    </li>
                <? else: ?>
                    <li class="nav-item">
                        <a class="nav-link active text-light" aria-current="page" href="Main/index">Главная</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active text-light" aria-current="page" href="Main/reg">Регистрация</a>
                    </li>   
                <? endif; ?>
                </ul>
                <? if(isset($_SESSION['user_id'])): ?>
                    <a class="btn btn-outline-success text-light" aria-current="page" href="Main/logout">Выход</a>
                <? else: ?>
                    <a class="btn btn-outline-success text-light" aria-current="page" href="Main/auto">Авторизация</a>
                <? endif; ?>
            </div>
        </div>
    </nav>