<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Подробнее о товаре</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id='modal_body'>
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleOrderModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="client/check_order" method="post">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleOrderModal">Заказать</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id='modal_body'>
        <input type="hidden" name="id_product" id='id_product'>
        <input type='number' class="form-control" name='quantity' id='quantity_all' value='1'>
        <select name='oplata' class="form-control">
          <option value="Наличка">Наличка</option>
          <option value="Банковская карта">Банковская карта</option>
        </select>
        <input type="datetime-local" value="<?=date('Y-m-d\TH:i')?>" class="form-control" name="datetime" id="">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Отменить</button>
        <button type="submit" class="btn btn-primary">Заказать</button>
      </div>
      </form>
    </div>
  </div>
</div>


<div class="modal fade" id="editOrderModal" tabindex="-1" aria-labelledby="editOrderModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="client/edit_order" method="post">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleOrderModal">Редактировать</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id='modal_body'>
        <input type="hidden" name="id_order" id='id_order'>
        <p><label for="editquantity">Количестов</label></p>
        <input type='number' class="form-control" name='col' id='editquantity' value='1'>
        <p><label for="date_order">Дата</label></p>
        <input type='datetime-local' class="form-control" name='date' id='date_order'>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
        <button type="submit" class="btn btn-primary">Изменить</button>
      </div>
      </form>
    </div>
  </div>
</div>
</div>
<script>
    function startData(col, width, unit){

      
        document.getElementById('modal_body').innerHTML = `<p><b>Количество</b>: ${col}</p><p><b>Вес</b>: ${width} ${unit}</p></p>`;
    }
    function orderData(id_product, col){
            document.getElementById('quantity_all').setAttribute('max', col);

      document.getElementById('id_product').value = id_product;
    }
    function editOrder(col, date, id_order){
          document.getElementById('editquantity').value = col;
          //document.getElementById('date_order').value = date;
          document.getElementById('id_order').value = id_order;
    }
</script>
<footer class="bg-dark text-white py-3">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <p class="mb-0">© 2025 Пекарня. Все права защищены.</p>
                <p class="small mb-0">Свежая выпечка ежедневно с 8:00 до 20:00</p>
            </div>
        </div>
    </div>
</footer>