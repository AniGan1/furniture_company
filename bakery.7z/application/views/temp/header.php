<base href="<?=base_url()?>">
<link rel="stylesheet" href="<?=base_url('/public/css/bootstrap.min.css');?>">
<link rel="stylesheet" href="<?=base_url('/public/css/style.css');?>">

<script src="/public/js/jquery-3.3.1.min.js"></script>
<script src="/public/js/bootstrap.min.js"></script> 
